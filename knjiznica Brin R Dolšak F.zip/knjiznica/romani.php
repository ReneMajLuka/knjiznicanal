<!DOCTYPE html>
<html lang="sl">
<head>
</head>
<body>
    <header>
    <h1>Spletna Knjigarna</h1>
        <nav>
            <a href="index.php">Domov</a>
            <a href="ponudba.php">Ponudba</a>
            <a href="kriminalke.php">Kriminalke</a>
            <a href="fantazija.php">Fantazije</a>
        </nav>
    </header>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Romani</title>
    <style>
        header {
            background-color: #333;
            color: white;
            padding: 1rem 0;
            text-align: center;
        }

        header nav a {
            color: white;
            margin: 0 1rem;
            text-decoration: none;
        }
        body {
            font-family: cursive;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            background-image: url(slike/odzadje1.jpg);
            opacity: 1.5;
            background-size: cover; 
            background-repeat: no-repeat; 
            background-attachment: fixed;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .book {
            margin-bottom: 20px;
            padding: 15px;
            border-bottom: 1px solid #ddd;
            display: flex;
            align-items: center;
        }

        .book img {
            width: 100px;
            height: auto;
            margin-right: 20px;
        }

        .book h2 {
            margin: 0;
            color: #333;
        }

        .book p {
            margin: 5px 0 0;
            color: #666;
        }
        @media (max-width: 768px) {
  .container {
    width: 90%;
    margin: 20px auto;
    padding: 15px;
  }
  .nav {
    flex-direction: column;
    align-items: center;
  }
  .nav a {
    width: 100%;
    padding: 10px;
    box-sizing: border-box;
  }
  .header h1 {
    font-size: 24px;
  }
  .logo {
    width: 40px;
    height: 35px;
  }
}

@media (max-width: 480px) {
  .container {
    width: 95%;
    margin: 10px auto;
    padding: 10px;
  }
  .header h1 {
    font-size: 20px;
  }
  .nav a {
    font-size: 14px;
  }
  button {
    font-size: 14px;
    padding: 8px 15px;
  }
  .logo {
    width: 30px;
    height: 25px;
  }
}
    </style>
</head>
<body>
    <div class="container">
        <h1>Romani</h1>
        <?php
include_once('povezava.php');
function get_knjige()

  {
      global $conn;
      $query = "SELECT * FROM book WHERE BookCategoryID = 3;";
      $res = $conn->query($query);
      $knjige = array();
      while ($knjiga = $res->fetch_object()) {
          array_push($knjige, $knjiga);
      }
      return $knjige;
  }
    $knjige = get_knjige();
    foreach ($knjige as $knjiga){
?>
        <div class="book">
            <a href='podrobnosti.php?id=<?php echo $knjiga->BookID ?>' ><img src='<?php echo $knjiga->BookCover ?>' alt="Harry Potter"></a>
            <div>
                <h2><?php echo $knjiga->Name ?></h2>
                <p><?php echo $knjiga->Content ?></p>
            </div>
        </div>
        <?php
    }
    ?>  
    </div>
</body>
</style>
</head>
<body>
    <header>
        <h1>Spletna Knjigarna</h1>
        <nav>
            <a href="ponudba.php">Ponudba</a>
            <a href="index.php">Domov</a>
            <a href="books.php">Knjige</a>
            
        </nav>
    </header>
    <main>
</html>
