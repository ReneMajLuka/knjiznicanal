-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Gostitelj: 127.0.0.1:3306
-- Čas nastanka: 01. jul 2024 ob 19.14
-- Različica strežnika: 5.7.40
-- Različica PHP: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Zbirka podatkov: `knjiznica`
--

-- --------------------------------------------------------

--
-- Struktura tabele `book`
--

DROP TABLE IF EXISTS `book`;
CREATE TABLE IF NOT EXISTS `book` (
  `BookID` int(16) NOT NULL,
  `Name` varchar(128) COLLATE ucs2_slovenian_ci NOT NULL,
  `Author` varchar(128) COLLATE ucs2_slovenian_ci NOT NULL,
  `Content` varchar(128) COLLATE ucs2_slovenian_ci NOT NULL,
  `BookCover` varchar(128) COLLATE ucs2_slovenian_ci NOT NULL,
  `BookCategoryID` int(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=ucs2 COLLATE=ucs2_slovenian_ci;

--
-- Odloži podatke za tabelo `book`
--

INSERT INTO `book` (`BookID`, `Name`, `Author`, `Content`, `BookCover`, `BookCategoryID`) VALUES
(2, 'Igra prestolov', 'George R.R. Martin', 'Skupek političnih in vojnih spletk za železni prestol', 'slike/got.jpg', 3),
(1, 'Harry Potter in kamen modrosti', 'J.K. Rowling', 'Pustolovščina mladega čarovnika na Bradavičarki.', 'slike/harry.jpg', 3),
(4, 'Eragon', 'Christopher Paolini', 'Deček najde zmajsko jajce in postane jezdec.', 'slike/Eragon.jpg', 2),
(3, 'Neskončna zgodba', 'Michael Ende', 'Fant potuje v fantazijski svet, da bi ga rešil', 'slike/ende.jpg', 2),
(5, 'Tiha priča', 'Liza Marklund', 'Preiskava umora na Švedskem.', 'slike/prica.jpg', 1),
(6, 'Dekle z zmajevim tatujem', 'Stieg Larsson', 'Novinarka in hekerka lovita serijskega morilca.', 'slike/tatu.jpg', 1);

-- --------------------------------------------------------

--
-- Struktura tabele `bookinfo`
--

DROP TABLE IF EXISTS `bookinfo`;
CREATE TABLE IF NOT EXISTS `bookinfo` (
  `BookID` int(32) NOT NULL,
  `Info` text COLLATE ucs2_slovenian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=ucs2 COLLATE=ucs2_slovenian_ci;

--
-- Odloži podatke za tabelo `bookinfo`
--

INSERT INTO `bookinfo` (`BookID`, `Info`) VALUES
(1, 'Zgodba se začne s Harryjem Potterjem, osirotelim dečkom, ki živi pri svojih okrutnih sorodnikih, družini Dursley. Na svoj enajsti rojstni dan Harry izve, da je čarovnik, in prejme pismo za vpis na čarovniško šolo Bradavičarko (Hogwarts School of Witchcraft and Wizardry). V svetu čarovnije Harry odkrije, da je postal slaven zaradi preživetja smrtonosnega uroka zlobnega čarovnika Lorda Voldemorta, ki je ubil njegove starše.\r\n\r\nOsrednja skrivnost knjige je kamen modrosti, čarobni artefakt, ki lahko lastniku omogoči nesmrtnost. Harry in njegovi prijatelji odkrijejo, da nekdo na šoli načrtuje krajo kamna. Z veliko poguma in spretnosti Harry, Hermiona in Ron premagajo številne ovire, da bi zaščitili kamen in preprečili njegovo zlorabo.'),
(2, 'Zgodba se osredotoča na politične in dinastične boje med plemiškimi družinami, ki se potegujejo za nadzor nad železnim prestolom in posledično nad Sedmimi kraljestvi. Med glavnimi družinami so:\r\n\r\nStark: Plemenska družina s sedežem na severu v gradu Winterfell, ki jo vodi Eddard \"Ned\" Stark. Starkovi so znani po svoji časti in zvestobi.\r\nLannister: Ena najbogatejših družin v kraljestvu, ki jo vodi Tywin Lannister. Njegova hči Cersei je poročena z Robertom Baratheonom, trenutnim kraljem Westerosa.\r\nBaratheon: Kraljevska družina, ki je prišla na oblast po uporniškem boju proti prejšnji dinastiji Targaryenov. Kralj Robert Baratheon vlada iz prestolnice King\'s Landing.\r\nTargaryen: Izgnana plemiška družina, ki je nekoč vladala Sedmim kraljestvom. Zadnja preživela člana, Viserys in Daenerys Targaryen, načrtujeta vrnitev na prestol.\r\nKnjiga se začne, ko Ned Stark sprejme vlogo Kraljevega pravega (Hand of the King) in se preseli v King\'s Landing. Medtem na severu Jon Snow, Nedov nezakonski sin, vstopi v Bratovščino Nočne straže, da bi varoval kraljestvo pred grožnjami onstran Zidu. Na vzhodu pa Daenerys Targaryen začne svojo pot, da bi si povrnila prestol svojega očeta.'),
(3, 'Neskončna zgodba (Die unendliche Geschichte), ki jo je napisal Michael Ende, je klasična fantazijska zgodba o dečku po imenu Bastian Balthazar Bux, ki v antikvarni knjigarni naleti na skrivnostno knjigo z naslovom \"Neskončna zgodba\". Ko začne brati, se znajde potopljen v čarobni svet Fantazije, ki je v nevarnosti. Kraljestvo, ki ga naseljujejo čudovita in nenavadna bitja, grozi uničenje zaradi misteriozne sile, imenovane Nič.\r\nBastian kmalu odkrije, da ni le bralec zgodbe, ampak igra ključno vlogo pri reševanju Fantazije. S pomočjo junaka Atreja in številnih drugih prijateljev mora Bastian premagati svoje strahove in dvome ter obnoviti svet domišljije in upanja.'),
(4, 'Eragon je prvi del fantazijske serije \"Dediscina\" (The Inheritance Cycle), ki jo je napisal Christopher Paolini. Zgodba se vrti okoli mladega dečka po imenu Eragon, ki v gorah najde skrivnostni moder kamen. Kmalu odkrije, da je kamen v resnici zmajevo jajce, iz katerega se izvali zmajček po imenu Safira. Eragon postane Zmajev jezdec, kar ga poveže s starodavno tradicijo in usodo, ki je prepletena s čarovnijo, močjo in nevarnostmi.\r\n Ko Eragon odkrije svojo novo moč, se skupaj s Safiro poda na pustolovščino, da bi premagal zlobnega kralja Galbatorixa, ki vlada z železno roko. Na svoji poti se sreča z mnogimi zavezniki in sovražniki ter se uči o svoji vlogi v boju za svobodo dežele Alagaësia.'),
(5, 'Vanished (švedski naslov: \"Försvunnen\") je kriminalni roman avtorice Lize Marklund, ki je del serije o novinarki Anniki Bengtzon. V tej napeti zgodbi se Annika znajde sredi preiskave izginotja priljubljene televizijske voditeljice, kt\'ere nenaden in skrivnosten izginotje sproži val špekulacij in medijske pozornosti.\r\nAnnika Bengtzon, ki je raziskovalna novinarka pri večjem časopisu, začne kopati po življenju in karieri izginule zvezde. Med preiskavo naleti na mrežo spletk, laži in nevarnih skrivnosti, ki segajo globoko v svet medijev in šovbiznisa. Obenem se Annika sooča tudi s svojimi osebnimi težavami in napetostmi v svojem zasebnem življenju.'),
(6, 'Dekle z zmajevim tatujem (originalni naslov: \"Män som hatar kvinnor\", kar pomeni \"Moški, ki sovražijo ženske\") je prvi del trilogije Millennium, ki jo je napisal švedski avtor Stieg Larsson. Knjiga sledi raziskovalnemu novinarju Mikaelu Blomkvistu in nadarjeni hekerki Lisbeth Salander, ki združita moči, da bi rešila skrivnost izginotja mlade dedinje Harriet Vanger, ki je izginila pred štiridesetimi leti.\r\nMikael Blomkvist, ki je ravnokar izgubil sodno bitko zaradi obrekovanja, se odloči sprejeti ponudbo Henrika Vangerja, starejšega poslovneža, da razišče primer Harrietinega izginotja. Skupaj z Lisbeth Salander odkrijeta mrežo družinskih skrivnosti, korupcije in nasilja.\r\nLisbeth Salander je enigmatična, a izjemno inteligentna in sposobna mlada ženska s težavno preteklostjo. Njena kompleksna osebnost in neizprosna narava jo naredijo za nepozabnega lika v sodobni literaturi.  ');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
