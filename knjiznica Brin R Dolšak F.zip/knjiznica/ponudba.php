<!DOCTYPE html>
<html lang="sl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ponudba Knjig</title>
  <style>
    body {
      font-family: cursive;
      margin: 0;
      background-image: url(slike/odzadje1.jpg);
            opacity: 1.5;
            background-size: cover; 
            background-repeat: no-repeat; 
            background-attachment: fixed;
    }
    .logo{
            width: 50px;
            height: 50px;
            margin-right: auto;
            margin-top: auto;
            

        }
    .header {
      background-color: #333;
      color: white;
      padding: 10px 0;
      text-align: center;
    }
    .nav {
      display: flex;
      justify-content: center;
      background-color: #444;
      text-align: center;
      
    }
    .nav a {
      color: white;
      padding: 14px 20px;
      text-decoration: none;
      text-align: center;
      margin-left: 40px;
      margin-right: 100px;
      align-items: center;
      
    }
    .nav a:hover {
      background-color: #ddd;
      color: black;
    }
    .content {
      padding: 20px;
      text-align: center;
    }
    .book-list {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
    }
    .book-item {
      border: 1.5px solid #ddd;
      border-color: black;
      margin: 10px;
      padding: 10px;
      width: 200px;
      text-align: center;
      background-color: white;
    }
    .book-item img {
      max-width: 100%;
      height: auto;
    }
    .footer {
      background-color: #333;
      color: white;
      text-align: center;
      padding: 10px 0;
      position: fixed;
      width: 100%;
      bottom: 0;
    }
    .cart-icon {
      margin-left: auto;
      margin-right: auto;
      color: #ddd;
    }
    .cart-icon img {
      width: 24px; 
      height: auto; 
      filter: invert(100%) sepia(0%) saturate(0%) hue-rotate(0deg) brightness(200%) contrast(100%);
    }
    @media (max-width: 768px) {
  .container {
    width: 90%;
    margin: 20px auto;
    padding: 15px;
  }
  .nav {
    flex-direction: column;
    align-items: center;
    background-color: black;
  }
  .nav a {
    width: 100%;
    padding: 10px;
    box-sizing: border-box;
    background-color: black;
  }
  .header h1 {
    font-size: 24px;
  }
  .logo {
    width: 40px;
    height: 35px;
    color: white;
  }
}

@media (max-width: 480px) {
  .container {
    width: 100%;
    margin: 10px auto;
    padding: 10px;
  }
  .header h1 {
    font-size: 20px;
  }
  .nav a {
    font-size: 14px;
  }
  button {
    font-size: 14px;
    padding: 8px 15px;
  }
  .logo {
    width: 30px;
    height: 25px;
  }
}
  </style>
</head>
<body>

<div class="header">
    <h1><img class="logo" src="slike/odzadje2.png" alt="Logo"> Spletna knjigarna </h1>
</div>

<div class="nav">
  <a href="index.php">Domov</a>
  <a href="books.php">Knjige</a>
  
</div>
<?php
include_once('povezava.php');
function get_knjige()
  {
      global $conn;
      $query = "SELECT * FROM book;";
      $res = $conn->query($query);
      $knjige = array();
      while ($knjiga = $res->fetch_object()) {
          array_push($knjige, $knjiga);
      }
      return $knjige;
  }
?>


<div class="content">

  
  <div class="book-list">
  <?php
    $knjige = get_knjige();
    foreach ($knjige as $knjiga){

    

  ?>
    <div class="book-item">
      <img src='<?php echo $knjiga->BookCover ?>' alt="Knjiga 1">
      <h4><?php echo $knjiga->Author ?></h4>
      <h3><?php echo $knjiga->Name ?></h3>
      <p><?php echo $knjiga->Content ?></p>
    </div>
    <?php
    }
    ?>


   
    <!-- Dodajte več knjig tukaj -->
  </div>
</div>


<div class="footer">
  &copy; 2024 Spletna Knjigarna
</div>


</body>
</html>
