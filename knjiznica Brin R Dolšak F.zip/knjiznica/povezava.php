<?php


//Poveži se z bazo
$conn = new mysqli('localhost', 'root', '', 'knjiznica', 3306);
//Nastavi kodiranje znakov, ki se uporablja pri komunikaciji z bazo
$conn->set_charset("UTF8");
?>