
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Knjige</title>
    <style>
        body {
            font-family: cursive;
            margin: 0;
            padding: 0;
            background-image: url(slike/odzadje1.jpg);
            opacity: 1.5;
            background-size: cover; 
            background-repeat: no-repeat; 
            background-attachment: fixed;
            
            
        }
        

        

        header {
            background-color: #333;
            color: white;
            padding: 1rem 0;
            text-align: center;
        }

        header nav a {
            color: white;
            margin: 0 1rem;
            text-decoration: none;
        }

        main {
            padding: 2rem;
            text-align: center;
            color: white;
        }

        footer {
            background-color: #333;
            color: white;
            padding: 1rem 0;
            text-align: center;
            position: absolute;
            bottom: 1;
            width: 100%;
        }

        .categories {
            margin-bottom: 2rem;
        }

        .categories button {
            margin: 0 0.5rem;
            padding: 0.5rem 1rem;
            cursor: pointer;
            color: white;
        }

        .book-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            color: white;
        }

        .book-item {
            border: 1px solid #ddd;
            margin: 1rem;
            padding: 1rem;
            width: 150px;
            text-align: left;
            background: white;
            
        }

        .book-item img {
            max-width: 100%;
            height: auto;
            background-color: white;
        }

        .book-info {
            margin-top: 1rem;
            color: black;
        }
        .button-link {
  display: inline-block;
  padding: 10px 20px;
  margin: 5px;
  background-color: white;
  color: black;
  text-decoration: none;
  border-radius: 5px;
  text-align: center;
}

.button-link:hover {
  background-color: #0056b3;
}
.cart-icon {
      margin-left: auto;
      margin-right: 20px;
      color: #ddd;
    }
    .cart-icon img {
      width: 24px; 
      height: auto; 
      filter: invert(100%) sepia(0%) saturate(0%) hue-rotate(0deg) brightness(200%) contrast(100%);
    }
    @media (max-width: 768px) {
  .container {
    width: 90%;
    margin: 20px auto;
    padding: 15px;
  }
  .nav {
    flex-direction: column;
    align-items: center;
  }
  .nav a {
    width: 100%;
    padding: 10px;
    box-sizing: border-box;
  }
  .header h1 {
    font-size: 24px;
  }
  .logo {
    width: 40px;
    height: 35px;
  }
}

@media (max-width: 480px) {
  .container {
    width: 95%;
    margin: 10px auto;
    padding: 10px;
  }
  .header h1 {
    font-size: 20px;
  }
  .nav a {
    font-size: 14px;
  }
  button {
    font-size: 14px;
    padding: 8px 15px;
  }
  .logo {
    width: 30px;
    height: 25px;
  }
}


    </style>
</head>
<body>
    <header>
        <h1>Spletna Knjigarna</h1>
        <nav>
            <a href="index.php">Domov</a>
            <a href="ponudba.php">Ponudba</a>
            <a href="romani.php">Romani</a>
            <a href="kriminalke.php">Kriminalke</a>
            <a href="fantazija.php">Fantazija</a>


            
        </nav>
    </header>
    
        </div>
        <div class="book-list">
            <div class="book-item">
                <img src="two towers.jpg" alt="Gospodar prstanov drugi del">
                <div class="book-info">
                    <h2>Knjiga meseca!</h2>
                    <h3>Gospodar prstanov</h3>
                    <p>J.R.R. Tolkien</p>
                    <p>Gospodar prstanov: Dva stolpa - bitka za Srednji svet.</p>
                </div>
            </div>
        </div>
    </main>
    <footer>
        <p>&copy; 2024 Spletna Knjigarna</p>
    </footer>
</body>

