<!DOCTYPE html>
<html lang="sl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Naročanje Knjig</title>
  <style>
    body {
      font-family: cursive;
      margin: 0;
      background-color: #f4f4f4;
      background-image: url(odzadje1.jpg);
            opacity: 1.5;
            background-size: cover; 
            background-repeat: no-repeat; 
            background-attachment: fixed;
    }
    .header {
      background-color: rgba(51, 51, 51, 0.8); 
      color: white;
      padding: 10px 0;
      text-align: center;
    }
    .nav {
      display: flex;
      justify-content: center;
      background-color: rgba(68, 68, 68, 0.8);
      padding: 10px 0;
    }
    .nav a {
      color: white;
      padding: 14px 20px;
      text-decoration: none;
      text-align: center;
    }
    .nav a:hover {
      background-color: #ddd;
      color: black;
    }
    .container {
      max-width: 600px;
      margin: 40px auto;
      padding: 20px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    h2 {
      text-align: center;
      color: #333;
    }
    label {
      display: block;
      margin: 15px 0 5px;
    }
    input[type="text"],
    input[type="email"],
    textarea,
    select {
      width: 100%;
      padding: 10px;
      margin: 5px 0 20px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }
    textarea {
      resize: vertical;
    }
    button {
      background-color: #333;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      display: block;
      width: 100%;
      font-size: 16px;
    }
    button:hover {
      background-color: #555;
    }
    .logo{
            width: 50px;
            height: 45px;
            align-items: center;
            margin-bottom: auto;
            text-align: center;
            margin-right: auto;
            margin-top: auto;
    }
    @media (max-width: 768px) {
  .container {
    width: 90%;
    margin: 20px auto;
    padding: 15px;
  }
  .nav {
    flex-direction: column;
    align-items: center;
  }
  .nav a {
    width: 100%;
    padding: 10px;
    box-sizing: border-box;
  }
  .header h1 {
    font-size: 24px;
  }
  .logo {
    width: 40px;
    height: 35px;
  }
}

@media (max-width: 480px) {
  .container {
    width: 95%;
    margin: 10px auto;
    padding: 10px;
  }
  .header h1 {
    font-size: 20px;
  }
  .nav a {
    font-size: 14px;
  }
  button {
    font-size: 14px;
    padding: 8px 15px;
  }
  .logo {
    width: 30px;
    height: 25px;
  }
}
  </style>
</head>
<body>

<div class="header">
    <h1><img class="logo" src="odzadje2.png" alt="Logo"> Spletna knjigarna </h1>
</div>

<div class="nav">
  <a href="index.php">Domov</a>
  <a href="books.php">Knjige</a>
  <a href="ponudba.php">Ponudba</a>
  
</div>

<div class="container">
  <h2>Naročanje Knjig</h2>
  <form action="submit_order.php" method="POST">
    <label for="name">Ime:</label>
    <input type="text" id="name" name="name" required>

    <label for="email">E-pošta:</label>
    <input type="email" id="email" name="email" required>

    <label for="address">Naslov:</label>
    <textarea id="address" name="address" rows="4" required></textarea>

    <label for="book">Izberite knjigo:</label>
    <select id="book" name="book" required>
      <option value="knjiga0">...</option>
      <option value="knjiga1">Gospodar prstanov</option>
      <option value="knjiga2">Dekle z zmajskim tatujem</option>
      <option value="knjiga3">Ime rože</option>
      <option value="knjiga4">Igra prestolov</option>
      <option value="knjiga5">Harry Potter in kamen modrosti</option>
      <option value="knjiga6">Ameriški bogovi</option>
      <option value="knjiga7">Temeraire</option>
      <option value="knjiga8">Ubiti ptico oponašalko</option>
      <option value="knjiga9">Šepetalka</option>
      <option value="knjiga10">Prevzetnost in prestranost</option>
      <option value="knjiga11">Tiha priča</option>
      <option value="knjiga12">Sherlock Holmes</option>
      <option value="knjiga13">Neskončna zgodba</option>
      <option value="knjiga14">Eragon</option>
      <option value="knjiga15">Kolo časa</option>
    </select>

    <label for="quantity">Količina:</label>
    <input type="number" id="quantity" name="quantity" min="1" max="10" required>

    <button type="submit">Oddaj naročilo</button>
  </form>
</div>

</body>
</html>
