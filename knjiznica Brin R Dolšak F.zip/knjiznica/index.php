
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spletna Knjigarna</title>
    <title></title>
    <style>
        
        body {
            font-family: cursive;
            margin: 0;
            padding: 0;
            background-image: url(slike/odzadje1.jpg);
            opacity: 1.5;
            background-size: cover; 
            background-repeat: no-repeat; 
            background-attachment: fixed;
        }

        header {
            background-color: #333;
            color: white;
            padding: 1rem 0;
            text-align: center;
        }
        .logo{
            width: 50px;
            height: 45px;
            align-items: center;
            margin-bottom: auto;
            text-align: center;
            margin-right: auto;
            margin-top: auto;
            

        }

        header nav a {
            color: white;
            margin: 0 1rem;
            text-decoration: none;
        }

        main {
            padding: 2rem;
            text-align: center;
            margin-top: 50px;
            background-color: white;
            margin-left: 100px;
            margin-right: 100px;
            border-color: burlywood;
            border-width: 1px;
            opacity: 0.8;
        }

        footer {
            background-color: #333;
            color: white;
            padding: 1rem 0;
            text-align: center;
            position: absolute;
            bottom: 0;
            width: 100%;
        }

        .categories {
            margin-bottom: 2rem;
        }

        .categories button {
            margin: 0 0.5rem;
            padding: 0.5rem 1rem;
            cursor: pointer;
        }

        .book-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            color: wheat;
        }

        .book-item {
            border: 1px solid #ddd;
            margin: 1rem;
            padding: 1rem;
            width: 200px;
            text-align: left;
            background-color: white;
        }

        .book-item img {
            max-width: 100%;
            height: auto;
        }

        .book-info {
            margin-top: 1rem;
        }
        .cart-icon {
      margin-left: auto;
      margin-right: 20px;
      color: #ddd;
    }
    .cart-icon img {
      width: 24px; 
      height: auto; 
      filter: invert(100%) sepia(0%) saturate(0%) hue-rotate(0deg) brightness(200%) contrast(100%);
    }
    @media (max-width: 768px) {
  .container {
    width: 90%;
    margin: 20px auto;
    padding: 15px;
  }
  .nav {
    flex-direction: column;
    align-items: center;
  }
  .nav a {
    width: 100%;
    padding: 10px;
    box-sizing: border-box;
  }
  .header h1 {
    font-size: 24px;
  }
  .logo {
    width: 40px;
    height: 35px;
  }
}

@media (max-width: 480px) {
  .container {
    width: 95%;
    margin: 10px auto;
    padding: 10px;
  }
  .header h1 {
    font-size: 20px;
  }
  .nav a {
    font-size: 14px;
  }
  button {
    font-size: 14px;
    padding: 8px 15px;
  }
  .logo {
    width: 30px;
    height: 25px;
  }
}
        
    </style>
</head>
<body>
    <header>
    <h1><img class="logo" src="slike/odzadje2.png" alt="Logo"> Spletna knjigarna </h1>
        
        <nav>
            <a href="ponudba.php">Ponudba</a>
            <a href="books.php">Knjige</a>
            
        </nav>
    </header>
    <main>
        
        <h2>Dobrodošli v spletni knjigarni</h2>
        <p>Na naši strani lahko najdete različne knjige razvrščene po kategorijah.</p>
        <p>V naši spletni knjigarni ponujamo širok izbor knjig za vse okuse in starostne skupine. Naša ponudba vključuje:</p>
  <ul>
    <li><strong>Romani:</strong> Klasični in sodobni romani, ki vas bodo popeljali v svet domišljije in čustev.</li>
    <li><strong>Kriminalke:</strong> Napeti trilerji in kriminalne zgodbe, ki vas bodo držale na robu stola.</li>
    <li><strong>Fantazija:</strong> Čarobni svetovi in epske dogodivščine za ljubitelje fantazijskih zgodb.</li>
   
  </ul>
  <p>Redno dodajamo nove naslove in skrbimo za raznolikost naše ponudbe, da boste vedno našli nekaj zanimivega za branje.</p>
</div>
        
    </main>
    <footer>
        <p>&copy; 2024 Spletna Knjigarna</p>
    </footer>
</body>

