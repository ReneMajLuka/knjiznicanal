<!DOCTYPE html>
<html lang="sl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Harry Potter in kamen modrosti - Spletna Knjigarna</title>
  <style>
    body {
      font-family: cursive;
      margin: 0;
      background-color: #f4f4f4;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      background-image: url('slike/odzadje1.jpg');
      background-size: cover;
      background-repeat: no-repeat;
      background-attachment: fixed;
    }
    .container {
      background-color: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      max-width: 800px;
      margin: 20px;
    }
    .book-image {
      text-align: center;
    }
    .book-image img {
      width: 100%;
      max-width: 400px;
      height: auto;
      border-radius: 8px;
    }
    .book-details {
      margin-top: 20px;
    }
    .book-details h1 {
      font-size: 24px;
      margin-bottom: 10px;
    }
    .book-details p {
      font-size: 16px;
      line-height: 1.5;
    }
    .back-link {
      display: inline-block;
      margin-top: 20px;
      padding: 10px 20px;
      background-color: #333;
      color: white;
      text-decoration: none;
      border-radius: 4px;
      transition: background-color 0.3s;
    }
    .back-link:hover {
      background-color: #555;
    }
  </style>
</head>
<body>
<?php
 include_once('povezava.php');
 $id = $_GET["id"];
 global $conn;
 $query = "SELECT book.*, bookinfo.Info FROM book LEFT JOIN bookinfo ON book.BookID = bookinfo.BookID WHERE book.BookID = $id;";
 $res = $conn->query($query);
 $knjiga = $res ->fetch_object();


 
?>

<div class="container">
  <div class="book-image">
    <img src='<?php echo $knjiga->BookCover ?>' alt="Harry Potter">
  </div>
  <div class="book-details">
    <h4><?php echo $knjiga->Author ?></h4>
    <h1><?php echo $knjiga->Name ?></h1>
    <p>
    <?php echo $knjiga->Info ?>
    </p>
    <a href="romani.php" class="back-link">Nazaj na glavno stran</a>
  </div>
</div>

</body>
</html>